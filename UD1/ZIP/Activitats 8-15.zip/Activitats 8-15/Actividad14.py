def frase(nombre):
    print("Hola", nombre)


frase("juan")
