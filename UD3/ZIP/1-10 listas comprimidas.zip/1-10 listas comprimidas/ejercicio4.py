import string

def contar():  
    contador=[numero for numero in string.ascii_lowercase]
    return contador

print(contar())