num1 = int(input("Introduce el numero 1 "))
num2 = int(input("Introduce el numero 2 "))
num3 = int(input("Introduce el numero 3 "))

suma = num1 + num2 + num3
resta = num1 - num2 - num3
multi = num1 * num2 * num3
division = num1 / num2 / num3

print(suma)
print(resta)
print(multi)
print(division)
