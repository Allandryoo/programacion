numero=int(input("Escribe un numero"))

if numero > 10:
    print ("Es mayor que 10")
else:
    print("Es menor que 10")