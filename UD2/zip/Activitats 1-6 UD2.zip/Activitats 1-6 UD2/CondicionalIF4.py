numero=int(input("Escribe un numero\n"))

if numero > -10 and numero < 10:
    print("OK")

