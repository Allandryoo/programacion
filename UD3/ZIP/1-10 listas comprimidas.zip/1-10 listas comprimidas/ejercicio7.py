frase="Adsad asdasd adead feaa regw efw"

palabra=[letra for letra in frase.split() if letra.lower().startswith("a")]

print(palabra)