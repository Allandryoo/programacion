alumno={"nombre": "alan", "edad":23, "curso":"segundo"}

print(alumno["nombre"])
print(alumno["edad"])