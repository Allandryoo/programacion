frase="Esta es una frase"

listar=[lista for lista in frase.split()]

print(listar)