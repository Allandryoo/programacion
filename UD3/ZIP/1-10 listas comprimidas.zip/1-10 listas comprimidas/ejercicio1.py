def contar():  
    contador=[numero for numero in range(1,11)]
    return contador

print(contar())