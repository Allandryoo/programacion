nombres = ["patricio", "alex", "goodboy2", "alan", "juan"]

for i in nombres:
    print(f"Hola {(i)}")
