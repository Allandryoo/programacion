priemros_pares=[numeros*2 for numeros in range(1,11)]

pares_entre=[numeros*2 for numeros in range(1,6) if numeros <= 10]

print(priemros_pares)
print(pares_entre)