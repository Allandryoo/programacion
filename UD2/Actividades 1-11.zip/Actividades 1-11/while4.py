numero= int(input("Itroduce un numero\n"))
i=1

while i<numero+1:
    if i%2==0:
        print(i)
    i+=1
    
