apellidos={"apellido1":"santos","2apellido":"vasco"}

alumno={"nombre": apellidos, "edad":23, "curso":"segundo","nota_final":9}

print(alumno)