dias = int(input("Introduce un numero de dias: "))

horas = dias*24

minutos = dias*1440

segundos = dias*3600

print(f"{dias} dias son {horas} horas")
print(f"{dias} dias son {minutos} minutos")
print(f"{dias} dias son {segundos} segundos")
