import string


contador = [numero for numero in string.ascii_lowercase if numero in "aeiou"]

print(contador)