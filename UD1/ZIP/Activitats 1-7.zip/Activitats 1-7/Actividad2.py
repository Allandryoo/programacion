i = 10

print(i)

i = 20

print(i)
