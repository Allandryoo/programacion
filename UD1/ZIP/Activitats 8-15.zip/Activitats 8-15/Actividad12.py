euros = int(input("Introduce la cantidad en euros: "))

dolares = euros*1.16
print(f"{euros}euros son {dolares} dolares")
