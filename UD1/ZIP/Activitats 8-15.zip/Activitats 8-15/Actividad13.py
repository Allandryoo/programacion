def frase():
    print("Esta es mi frase")


frase()
