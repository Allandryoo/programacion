a = int(input("Base "))
b = int(input("Exponente "))

expo = a ** b

print(expo)
