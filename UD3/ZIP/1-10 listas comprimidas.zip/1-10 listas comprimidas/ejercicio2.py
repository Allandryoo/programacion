def contar(num):
    contador=[numero**num for numero in range(1,11)]
    return contador

print(contar(3))

print(contar(2))