numero=int(input("Escribe un numero\n"))

if numero*2 > -10 and numero*2 < 10:
    print("OK")
    
if numero%2==0:
    print("Es par")
else:
    print("Es impar")    

