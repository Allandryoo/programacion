nombre = input("Introduce un nombre: ")

print("Hola " + nombre)
print("Adios " + nombre)
