a = 10
b = 5

a, b = b, a

print(a)
print(b)
