a = int(input("Introduce numero 1 "))
b = int(input("Introduce nuemro 2 "))

resto = a % b

print(resto)
