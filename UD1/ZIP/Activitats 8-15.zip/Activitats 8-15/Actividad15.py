def doble(num):
    print(num*2)


doble(2)
