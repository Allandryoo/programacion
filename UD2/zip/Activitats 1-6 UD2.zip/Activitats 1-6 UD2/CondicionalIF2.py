nombre=input("Escribe un nombre\n")

if nombre == "allandryo":
    print(f"Bienvenido {nombre}")
else:
    print("No eres quien esperaba")


