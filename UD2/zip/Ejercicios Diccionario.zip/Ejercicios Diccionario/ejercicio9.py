alumno={"Alan": {"edad" : 23, "nota" : 5}}


alumno_nuevo={"Alan":alumno["Alan"],"Marta": {"edad": 21, "nota": 8}}

print(alumno_nuevo)