for tabla in range(1,11):
    print(f"Tabla del {tabla}")
    for multi in range(1,11):
        print(tabla*multi)